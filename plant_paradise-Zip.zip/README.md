# Plant Paradise Management System

A fresh Data Structures and Algorithmic Problem Solving project based on the approved proposal. This project is separate from VaultPay.

## Scope from the proposal
- Plant catalogue CRUD with a Linked List demonstration.
- Stack for recent actions and arithmetic expression processing.
- Linked-list-based Queue for processing orders in arrival order.
- Binary Tree traversals and a plant-ID Binary Search Tree.
- Nursery-section Graph using an adjacency list and BFS.
- Linear Search, Binary Search over sorted plant IDs, and Bubble Sort.
- Greedy plant recommendations that stay within the customer's budget.

## Initial setup
- `database/schema.sql` creates the project database tables.
- `database/connection.py` reads local settings from `.env`.
- `app.py` provides plant catalogue create, read, update, delete, and search endpoints.
- `dsa/linked_list.py` implements the singly linked list used to traverse and linearly search the catalogue.
- Customer creation and listing endpoints are available at `/api/customers`.
- Order creation records items and stock in MySQL; `/api/orders/process-next` moves the oldest queued order to Processing using `dsa/linked_queue.py`.
- `/api/orders/<order_id>/complete` completes a Processing order.
- One dashboard website switches between Dashboard, Plants, Customers, and Orders from its menu without navigating away from the app.
- Plant management provides a form, catalogue table, search, edit, and delete controls; order management shows the FIFO queue.
- No sample plants, customers, or orders have been inserted.

## Start on Windows
1. Create and activate a virtual environment: `py -3.13 -m venv .venv` then `.venv\Scripts\activate`.
2. Install dependencies: `python -m pip install -r requirements.txt`.
3. Copy `.env.example` to `.env` and enter your local MySQL password there.
4. Run `database/schema.sql` in MySQL Workbench.
5. Start the app with `python app.py`, then open `http://127.0.0.1:5000/`.

Next implementation phases: stack, tree/BST operations, nursery-section graph and BFS, sorting/searching, and greedy budget recommendations.
