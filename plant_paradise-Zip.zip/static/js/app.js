function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (char) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[char]);
}

async function requestJson(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) }
  });
  const result = await response.json();
  if (!response.ok) throw new Error(result.message || "The request could not be completed.");
  return result;
}

async function checkDatabase() {
  const badge = document.getElementById("database-status");
  try {
    const result = await requestJson("/api/health");
    badge.textContent = result.ok ? "MySQL connected" : "MySQL unavailable";
    badge.classList.toggle("offline", !result.ok);
  } catch {
    badge.textContent = "Cannot reach MySQL";
    badge.classList.add("offline");
  }
}

function setNotice(element, message, success = false) {
  element.textContent = message;
  element.className = success ? "notice success" : "notice error-text";
}

async function bootDashboard() {
  if (!document.getElementById("summary-plants")) return;
  try {
    const data = await requestJson("/api/summary");
    document.getElementById("summary-plants").textContent = data.plant_count;
    document.getElementById("summary-customers").textContent = data.customer_count;
    document.getElementById("summary-orders").textContent = data.order_count;
    document.getElementById("summary-queued").textContent = data.queued_count;
  } catch {
    for (const id of ["summary-plants", "summary-customers", "summary-orders", "summary-queued"]) {
      document.getElementById(id).textContent = "—";
    }
  }
}

function bootPlants() {
  const form = document.getElementById("plant-form");
  if (!form) return;

  const rows = document.getElementById("plant-rows");
  const notice = document.getElementById("notice");
  const searchInput = document.getElementById("search-input");
  const plantIdInput = document.getElementById("plant-id");
  const saveButton = document.getElementById("save-button");
  const cancelButton = document.getElementById("cancel-edit");
  const idSearch = document.getElementById("plant-id-search");
  const sortSelect = document.getElementById("plant-sort");

  let plantsById = new Map();
  let searchTimer;

  async function loadPlants() {
    rows.innerHTML = '<tr><td colspan="7" class="empty">Loading catalogue…</td></tr>';

    try {
      const nameQuery = searchInput.value.trim();
      const result = await requestJson(
        `/api/plants${nameQuery ? `?q=${encodeURIComponent(nameQuery)}` : ""}`
      );

      let shownPlants = result.plants;
      const idText = idSearch ? idSearch.value.trim() : "";

      if (idText) {
        const targetId = Number(idText);
        let low = 0;
        let high = shownPlants.length - 1;
        let foundPlant = null;

        while (low <= high) {
          const middle = Math.floor((low + high) / 2);
          const currentId = Number(shownPlants[middle].plant_id);

          if (currentId === targetId) {
            foundPlant = shownPlants[middle];
            break;
          } else if (currentId < targetId) {
            low = middle + 1;
          } else {
            high = middle - 1;
          }
        }

        shownPlants = foundPlant ? [foundPlant] : [];
      }

      if (sortSelect && sortSelect.value === "price") {
        shownPlants = [...shownPlants];

        for (let i = 0; i < shownPlants.length; i++) {
          for (let j = 0; j < shownPlants.length - i - 1; j++) {
            if (Number(shownPlants[j].price) > Number(shownPlants[j + 1].price)) {
              [shownPlants[j], shownPlants[j + 1]] =
                [shownPlants[j + 1], shownPlants[j]];
            }
          }
        }
      }

      plantsById = new Map(
        shownPlants.map((plant) => [Number(plant.plant_id), plant])
      );

      document.getElementById("plant-count").textContent = shownPlants.length;

      const note = document.getElementById("algorithm-note");
      if (idText) {
        note.textContent = "Plant ID search uses binary search.";
      } else if (sortSelect && sortSelect.value === "price") {
        note.textContent = "Plants are sorted by price using bubble sort.";
      } else if (nameQuery) {
        note.textContent = "Search uses a linear scan through the singly linked list.";
      } else {
        note.textContent = "Catalogue displayed by traversing the singly linked list.";
      }

      rows.innerHTML = shownPlants.length
        ? shownPlants.map((plant) => `
          <tr>
            <td class="id-cell">${plant.plant_id}</td>
            <td><strong>${escapeHtml(plant.plant_name)}</strong>
              <small>${escapeHtml(plant.sunlight_requirement || "Sunlight not set")}</small>
            </td>
            <td>${escapeHtml(plant.category_name)}</td>
            <td>₹${Number(plant.price).toFixed(2)}</td>
            <td>${plant.stock_quantity}</td>
            <td>${escapeHtml(plant.water_requirement || "Watering not set")}</td>
            <td class="actions">
              <button class="link-button" data-edit="${plant.plant_id}" type="button">Edit</button>
              <button class="link-button danger" data-delete="${plant.plant_id}" type="button">Delete</button>
            </td>
          </tr>`).join("")
        : '<tr><td colspan="7" class="empty">No matching plants found.</td></tr>';
    } catch (error) {
      rows.innerHTML =
        `<tr><td colspan="7" class="empty error-text">${escapeHtml(error.message)}</td></tr>`;
    }
  }

  function resetForm() {
    form.reset();
    plantIdInput.value = "";
    form.elements.stock_quantity.value = 0;
    form.elements.recommendation_priority.value = 1;
    document.getElementById("form-heading").textContent = "Add a plant";
    saveButton.textContent = "Add plant";
    cancelButton.classList.add("hidden");
  }

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const data = Object.fromEntries(new FormData(form).entries());
    data.price = Number(data.price);
    data.stock_quantity = Number(data.stock_quantity);
    data.recommendation_priority = Number(data.recommendation_priority);
    const id = plantIdInput.value;

    saveButton.disabled = true;
    notice.textContent = "Saving plant…";
    notice.className = "notice";

    try {
      const result = await requestJson(id ? `/api/plants/${id}` : "/api/plants", {
        method: id ? "PUT" : "POST",
        body: JSON.stringify(data)
      });
      setNotice(notice, result.message, true);
      resetForm();
      await loadPlants();
    } catch (error) {
      setNotice(notice, error.message);
    } finally {
      saveButton.disabled = false;
    }
  });

  cancelButton.addEventListener("click", resetForm);

  rows.addEventListener("click", async (event) => {
    const editButton = event.target.closest("[data-edit]");
    const deleteButton = event.target.closest("[data-delete]");

    if (editButton) {
      const plant = plantsById.get(Number(editButton.dataset.edit));
      if (!plant) return;

      plantIdInput.value = plant.plant_id;
      for (const field of [
        "plant_name", "category_name", "price", "stock_quantity",
        "sunlight_requirement", "water_requirement", "recommendation_priority"
      ]) {
        form.elements[field].value = plant[field] ?? "";
      }

      document.getElementById("form-heading").textContent = `Edit ${plant.plant_name}`;
      saveButton.textContent = "Save changes";
      cancelButton.classList.remove("hidden");
      form.scrollIntoView({ behavior: "smooth", block: "start" });
    }

    if (deleteButton) {
      const id = Number(deleteButton.dataset.delete);
      const plant = plantsById.get(id);
      if (!plant || !window.confirm(`Delete ${plant.plant_name}?`)) return;

      try {
        const result = await requestJson(`/api/plants/${id}`, { method: "DELETE" });
        setNotice(notice, result.message, true);
        await loadPlants();
      } catch (error) {
        setNotice(notice, error.message);
      }
    }
  });

  searchInput.addEventListener("input", () => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(loadPlants, 250);
  });

  if (idSearch) idSearch.addEventListener("input", loadPlants);
  if (sortSelect) sortSelect.addEventListener("change", loadPlants);

  loadPlants();
}

function bootCustomers() {
  const form = document.getElementById("customer-form");
  if (!form) return;
  const rows = document.getElementById("customer-rows");
  const notice = document.getElementById("customer-notice");

  async function loadCustomers() {
    try {
      const result = await requestJson("/api/customers");
      document.getElementById("customer-count").textContent = result.count;
      rows.innerHTML = result.customers.length ? result.customers.map((customer) => `
        <tr><td class="id-cell">${customer.customer_id}</td><td><strong>${escapeHtml(customer.customer_name)}</strong></td>
        <td>${escapeHtml(customer.email || "—")}</td><td>${escapeHtml(customer.phone || "—")}</td>
        <td>${new Date(customer.created_at).toLocaleDateString()}</td></tr>`).join("")
        : '<tr><td colspan="5" class="empty">No customers added yet.</td></tr>';
    } catch (error) {
      rows.innerHTML = `<tr><td colspan="5" class="empty error-text">${escapeHtml(error.message)}</td></tr>`;
    }
  }

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const data = Object.fromEntries(new FormData(form).entries());
    try {
      const result = await requestJson("/api/customers", { method: "POST", body: JSON.stringify(data) });
      setNotice(notice, result.message, true);
      form.reset();
      await loadCustomers();
    } catch (error) {
      setNotice(notice, error.message);
    }
  });
  loadCustomers();
}

function bootOrders() {
  const form = document.getElementById("order-form");
  if (!form) return;
  const rows = document.getElementById("order-rows");
  const notice = document.getElementById("order-notice");
  const customerSelect = document.getElementById("order-customer");
  const plantSelect = document.getElementById("order-plant");

  async function loadReferences() {
    try {
      const customers = await requestJson("/api/customers");
      customerSelect.innerHTML = '<option value="">Choose a customer</option>' + customers.customers.map((customer) => `<option value="${customer.customer_id}">${escapeHtml(customer.customer_name)} (#${customer.customer_id})</option>`).join("");
    } catch { customerSelect.innerHTML = '<option value="">Could not load customers</option>'; }
    try {
      const plants = await requestJson("/api/plants");
      const available = plants.plants.filter((plant) => Number(plant.stock_quantity) > 0);
      plantSelect.innerHTML = '<option value="">Choose a plant</option>' + available.map((plant) => `<option value="${plant.plant_id}">${escapeHtml(plant.plant_name)} · ₹${Number(plant.price).toFixed(2)} · stock ${plant.stock_quantity}</option>`).join("");
      if (!available.length) plantSelect.innerHTML = '<option value="">No plants in stock</option>';
    } catch { plantSelect.innerHTML = '<option value="">Could not load plants</option>'; }
  }

  async function loadOrders() {
    try {
      const result = await requestJson("/api/orders");
      document.getElementById("queue-count").textContent = result.queued_count;
      document.getElementById("queue-note").textContent = `${result.method} Queue order IDs: ${result.queued_order_ids.length ? result.queued_order_ids.join(" → ") : "none"}.`;
      rows.innerHTML = result.orders.length ? result.orders.map((order) => `
        <tr><td class="id-cell">#${order.order_id}</td><td>${escapeHtml(order.customer_name)}</td>
        <td><span class="status-pill status-${order.order_status.toLowerCase()}">${escapeHtml(order.order_status)}</span></td>
        <td>₹${Number(order.order_total).toFixed(2)}</td><td>${new Date(order.created_at).toLocaleString()}</td>
        <td>${order.order_status === "Processing" ? `<button class="link-button" type="button" data-complete="${order.order_id}">Complete</button>` : "—"}</td></tr>`).join("")
        : '<tr><td colspan="6" class="empty">No orders placed yet.</td></tr>';
    } catch (error) {
      rows.innerHTML = `<tr><td colspan="6" class="empty error-text">${escapeHtml(error.message)}</td></tr>`;
    }
  }

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const data = Object.fromEntries(new FormData(form).entries());
    const payload = { customer_id: Number(data.customer_id), items: [{ plant_id: Number(data.plant_id), quantity: Number(data.quantity) }] };
    try {
      const result = await requestJson("/api/orders", { method: "POST", body: JSON.stringify(payload) });
      setNotice(notice, `${result.message} Order #${result.order_id}, total ₹${result.order_total.toFixed(2)}.`, true);
      form.elements.quantity.value = 1;
      await Promise.all([loadOrders(), loadReferences()]);
    } catch (error) {
      setNotice(notice, error.message);
    }
  });

  document.getElementById("process-next").addEventListener("click", async () => {
    try {
      const result = await requestJson("/api/orders/process-next", { method: "POST", body: "{}" });
      setNotice(notice, `${result.message} Order #${result.order_id}.`, true);
      await loadOrders();
    } catch (error) { setNotice(notice, error.message); }
  });

  rows.addEventListener("click", async (event) => {
    const button = event.target.closest("[data-complete]");
    if (!button) return;
    try {
      const result = await requestJson(`/api/orders/${button.dataset.complete}/complete`, { method: "POST", body: "{}" });
      setNotice(notice, result.message, true);
      await loadOrders();
    } catch (error) { setNotice(notice, error.message); }
  });

  loadReferences();
  loadOrders();
}

function bootRecommendations() {
  const form = document.getElementById("recommendation-form");
  if (!form) return;

  const budgetInput = document.getElementById("recommendation-budget");
  const notice = document.getElementById("recommendation-notice");
  const resultsBox = document.getElementById("recommendation-results");

  form.addEventListener("submit", async (event) => {
    event.preventDefault();

    const budget = Number(budgetInput.value);
    resultsBox.innerHTML = "";
    notice.textContent = "Finding plants…";
    notice.className = "notice";

    try {
      const result = await requestJson(
        `/api/recommendations?budget=${encodeURIComponent(budget)}`
      );

      if (result.recommendations.length === 0) {
        notice.textContent = "No in-stock plants fit within this budget.";
        return;
      }

      resultsBox.innerHTML = `
        <h3>Suggested plants</h3>
        <ul>
          ${result.recommendations.map((plant) => `
            <li>${escapeHtml(plant.plant_name)} — ₹${Number(plant.price).toFixed(2)}</li>
          `).join("")}
        </ul>
        <p>Spent: ₹${Number(result.spent).toFixed(2)}</p>
        <p>Remaining: ₹${Number(result.remaining).toFixed(2)}</p>
      `;

      notice.textContent = "Recommendations ready.";
      notice.className = "notice success";
    } catch (error) {
      notice.textContent = error.message;
      notice.className = "notice error-text";
    }
  });
}
function bootActions() {
  const list = document.getElementById("action-list");
  const notice = document.getElementById("action-notice");
  const removeButton = document.getElementById("remove-latest-action");

  async function loadActions() {
    try {
      const result = await requestJson("/api/actions");

      list.innerHTML = result.actions.length
        ? result.actions.map((action) =>
            `<li>${escapeHtml(action.method)} ${escapeHtml(action.path)}</li>`
          ).join("")
        : "<li>No recent actions.</li>";
    } catch (error) {
      list.innerHTML = `<li>${escapeHtml(error.message)}</li>`;
    }
  }

  removeButton.addEventListener("click", async () => {
    try {
      const result = await requestJson("/api/actions/pop", {
        method: "POST",
        body: "{}"
      });
      notice.textContent = result.message;
      notice.className = "notice success";
      await loadActions();
    } catch (error) {
      notice.textContent = error.message;
      notice.className = "notice error-text";
      await loadActions();
    }
  });

  loadActions();
}
function bootCalculator() {
  const form = document.getElementById("expression-form");
  if (!form) return;

  const input = document.getElementById("expression-input");
  const notice = document.getElementById("expression-notice");
  const resultBox = document.getElementById("expression-result");

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    resultBox.textContent = "";

    try {
      const result = await requestJson("/api/calculate", {
        method: "POST",
        body: JSON.stringify({ expression: input.value.trim() })
      });

      notice.textContent = "Calculation complete.";
      notice.className = "notice success";
      resultBox.textContent = `Result: ${result.result}`;
    } catch (error) {
      notice.textContent = error.message;
      notice.className = "notice error-text";
    }
  });
}
function bootPlantTree() {
  const traversalForm = document.getElementById("tree-traversal-form");
  const searchForm = document.getElementById("tree-search-form");
  if (!traversalForm || !searchForm) return;

  const treeResults = document.getElementById("tree-results");
  const searchId = document.getElementById("tree-search-id");
  const searchNotice = document.getElementById("tree-search-notice");
  const searchResult = document.getElementById("tree-search-result");

  traversalForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const order = document.getElementById("tree-order").value;

    try {
      const result = await requestJson(
        `/api/plant-tree?order=${encodeURIComponent(order)}`
      );

      treeResults.innerHTML = result.plants.length
        ? `<p>${escapeHtml(result.method)}</p><ul>${
            result.plants.map((plant) =>
              `<li>${escapeHtml(plant.plant_name)} (ID ${plant.plant_id})</li>`
            ).join("")
          }</ul>`
        : "<p>No plants are available for the tree.</p>";
    } catch (error) {
      treeResults.textContent = error.message;
    }
  });

  searchForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    try {
      const result = await requestJson(
        `/api/plant-tree?id=${encodeURIComponent(searchId.value)}`
      );

      if (result.found) {
        searchNotice.textContent = "Plant found in the BST.";
        searchNotice.className = "notice success";
        searchResult.textContent =
          `${result.plant.plant_name} — ID ${result.plant.plant_id}`;
      } else {
        searchNotice.textContent = "Plant ID not found in the BST.";
        searchNotice.className = "notice";
        searchResult.textContent = "";
      }
    } catch (error) {
      searchNotice.textContent = error.message;
      searchNotice.className = "notice error-text";
    }
  });
}
async function loadNurserySections() {
  const result = await requestJson("/api/nursery-graph");
  const sections = result.sections;

  const optionHtml = sections.length
    ? `<option value="">Choose a section</option>${
        sections.map((section) =>
          `<option value="${section.section_id}">${escapeHtml(section.section_name)} (#${section.section_id})</option>`
        ).join("")
      }`
    : '<option value="">Add sections first</option>';

  document.getElementById("section-one").innerHTML = optionHtml;
  document.getElementById("section-two").innerHTML = optionHtml;
  document.getElementById("bfs-start").innerHTML = optionHtml;
}

function bootNurseryGraph() {
  const sectionForm = document.getElementById("section-form");
  if (!sectionForm) return;

  const sectionNotice = document.getElementById("section-notice");
  const connectionForm = document.getElementById("connection-form");
  const connectionNotice = document.getElementById("connection-notice");
  const bfsForm = document.getElementById("bfs-form");
  const bfsNotice = document.getElementById("bfs-notice");
  const bfsResults = document.getElementById("bfs-results");

  loadNurserySections().catch((error) => {
    setNotice(sectionNotice, error.message);
  });

  sectionForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const formData = Object.fromEntries(new FormData(sectionForm).entries());

    try {
      const result = await requestJson("/api/nursery-sections", {
        method: "POST",
        body: JSON.stringify(formData)
      });

      sectionForm.reset();
      setNotice(sectionNotice, result.message, true);
      await loadNurserySections();
    } catch (error) {
      setNotice(sectionNotice, error.message);
    }
  });

  connectionForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const formData = Object.fromEntries(new FormData(connectionForm).entries());
    formData.section_id = Number(formData.section_id);
    formData.connected_section_id = Number(formData.connected_section_id);

    try {
      const result = await requestJson("/api/section-connections", {
        method: "POST",
        body: JSON.stringify(formData)
      });

      setNotice(connectionNotice, result.message, true);
      await loadNurserySections();
    } catch (error) {
      setNotice(connectionNotice, error.message);
    }
  });

  bfsForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const startId = document.getElementById("bfs-start").value;

    try {
      const result = await requestJson(
        `/api/nursery-graph?start_id=${encodeURIComponent(startId)}`
      );

      bfsResults.innerHTML = result.traversal.length
        ? `<ol>${result.traversal.map((section) =>
            `<li>${escapeHtml(section.section_name)} (ID ${section.section_id})</li>`
          ).join("")}</ol>`
        : "<p>No connected sections were found.</p>";

      setNotice(bfsNotice, "BFS traversal complete.", true);
    } catch (error) {
      setNotice(bfsNotice, error.message);
      bfsResults.innerHTML = "";
    }
  });
}

checkDatabase();
bootDashboard();
bootPlants();
bootCustomers();
bootOrders();
bootRecommendations();
bootActions();
bootCalculator();
bootPlantTree();
bootNurseryGraph();

const viewTitles = {
  dashboard: "Dashboard",
  plants: "Plants",
  customers: "Customers",
  orders: "Orders",
  sections: "Nursery Sections"
};
function showView(viewName, updateHash = false) {
  if (!viewTitles[viewName]) viewName = "dashboard";
  document.querySelectorAll("[data-view]").forEach((view) => {
    const active = view.dataset.view === viewName;
    view.hidden = !active;
    view.classList.toggle("active", active);
  });
  document.querySelectorAll("[data-view-target]").forEach((button) => {
    const active = button.dataset.viewTarget === viewName;
    button.classList.toggle("active", active);
    if (active) button.setAttribute("aria-current", "page");
    else button.removeAttribute("aria-current");
  });
  document.getElementById("view-title").textContent = viewTitles[viewName];
  if (updateHash && location.hash !== `#${viewName}`) history.pushState(null, "", `#${viewName}`);
}

document.addEventListener("click", (event) => {
  const button = event.target.closest("[data-view-target]");
  if (button) showView(button.dataset.viewTarget, true);
});
window.addEventListener("hashchange", () => showView(location.hash.slice(1)));
showView(location.hash.slice(1) || "dashboard");
