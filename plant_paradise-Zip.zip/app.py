from decimal import Decimal, InvalidOperation

from flask import Flask, jsonify, redirect, render_template, request
from mysql.connector import Error

from database.connection import get_connection
from dsa.linked_list import LinkedList
from dsa.linked_queue import LinkedQueue
from algorithms.searching_sorting import bubble_sort_by_price, binary_search_by_id
from algorithms.recommendations import recommend_plants_within_budget
from dsa.linked_stack import LinkedStack, evaluate_postfix
from dsa.plant_tree import PlantBST
from dsa.nursery_graph import NurseryGraph
app = Flask(__name__)
action_history = LinkedStack()

@app.after_request
def record_successful_action(response):
    if (
        request.path.startswith("/api/")
        and request.path != "/api/actions/pop"
        and request.method in {"POST", "PUT", "DELETE"}
        and response.status_code < 400
    ):
        action_history.push({
            "method": request.method,
            "path": request.path,
        })

    return response


@app.get("/api/actions")
def get_action_history():
    return jsonify({
        "actions": action_history.to_list(),
        "count": len(action_history),
    })


@app.post("/api/actions/pop")
def remove_latest_action():
    action = action_history.pop()

    if action is None:
        return jsonify({"message": "There are no recent actions."}), 404

    return jsonify({
        "message": "Latest action removed from history.",
        "action": action,
        "actions": action_history.to_list(),
    })

def _read_plants(connection):
    """Read the catalogue from MySQL and traverse it through a linked list."""
    cursor = connection.cursor(dictionary=True)
    cursor.execute(
        """
        SELECT p.plant_id, p.plant_name, c.category_name, p.price,
               p.stock_quantity, p.sunlight_requirement, p.water_requirement,
               p.recommendation_priority
        FROM plants AS p
        JOIN categories AS c ON c.category_id = p.category_id
        ORDER BY p.plant_id
        """
    )
    rows = cursor.fetchall()
    cursor.close()

    catalogue = LinkedList()
    for row in rows:
        row["price"] = float(row["price"])
        catalogue.append(row)
    return catalogue

def _plant_values(data):
    name = str(data.get("plant_name", "")).strip()
    category = str(data.get("category_name", "")).strip()
    if not name or not category:
        raise ValueError("Plant name and category are required.")

    try:
        price = Decimal(str(data.get("price", "")))
        stock = int(data.get("stock_quantity", 0))
        priority = int(data.get("recommendation_priority", 1))
    except (InvalidOperation, TypeError, ValueError):
        raise ValueError("Enter a valid price, stock quantity, and priority.") from None

    if not price.is_finite() or price < 0:
        raise ValueError("Price must be zero or greater.")
    if stock < 0:
        raise ValueError("Stock quantity must be zero or greater.")
    if priority < 1:
        raise ValueError("Recommendation priority must be at least 1.")

    return {
        "plant_name": name,
        "category_name": category,
        "price": price,
        "stock_quantity": stock,
        "sunlight_requirement": str(data.get("sunlight_requirement", "")).strip() or None,
        "water_requirement": str(data.get("water_requirement", "")).strip() or None,
        "recommendation_priority": priority,
    }


def _category_id(cursor, category_name):
    cursor.execute(
        "INSERT IGNORE INTO categories (category_name) VALUES (%s)",
        (category_name,),
    )
    cursor.execute(
        "SELECT category_id FROM categories WHERE category_name = %s",
        (category_name,),
    )
    category = cursor.fetchone()
    if not category:
        raise RuntimeError("Could not create or find the selected category.")
    return category[0]


@app.get("/")
def home():
    return render_template("index.html", active="dashboard")


@app.get("/plants")
def plants_page():
    return redirect("/#plants")


@app.get("/customers")
def customers_page():
    return redirect("/#customers")


@app.get("/orders")
def orders_page():
    return redirect("/#orders")


@app.get("/api/health")
def health():
    connection = None
    try:
        connection = get_connection()
        return jsonify({"ok": True, "database": "connected"})
    except Error:
        app.logger.exception("Database health check failed")
        return jsonify({"ok": False, "database": "unavailable"}), 503
    finally:
        if connection:
            connection.close()


@app.get("/api/summary")
def summary():
    connection = None
    try:
        connection = get_connection()
        cursor = connection.cursor(dictionary=True)
        cursor.execute(
            """
            SELECT
              (SELECT COUNT(*) FROM plants) AS plant_count,
              (SELECT COUNT(*) FROM customers) AS customer_count,
              (SELECT COUNT(*) FROM orders) AS order_count,
              (SELECT COUNT(*) FROM orders WHERE order_status = 'Queued') AS queued_count,
              (SELECT COALESCE(SUM(stock_quantity), 0) FROM plants) AS stock_count
            """
        )
        result = cursor.fetchone()
        cursor.close()
        return jsonify(result)
    except Error:
        app.logger.exception("Could not load dashboard summary")
        return jsonify({"message": "Could not load dashboard summary from MySQL."}), 503
    finally:
        if connection:
            connection.close()


@app.get("/api/plants")
def list_plants():
    connection = None
    try:
        connection = get_connection()
        catalogue = _read_plants(connection)
        plants = catalogue.to_list()

        plant_id = request.args.get("id", type=int)
        query = request.args.get("q", "").strip().casefold()
        sort_by = request.args.get("sort", "").strip().casefold()

        if plant_id is not None:
            match = binary_search_by_id(plants, plant_id)
            plants = [match] if match else []
            method = "Binary search by plant ID"

        elif query:
            match = catalogue.find(
                lambda plant: query in plant["plant_name"].casefold()
            )
            plants = [match] if match else []
            method = "Linked-list linear search by name"

        elif sort_by == "price":
            plants = bubble_sort_by_price(plants)
            method = "Bubble Sort by price"

        else:
            method = "Linked-list traversal"

        return jsonify({
            "plants": plants,
            "count": len(plants),
            "method": method
        })

    except Error:
        app.logger.exception("Could not load the plant catalogue")
        return jsonify({"message": "Could not load plants from MySQL."}), 503

    finally:
        if connection:
            connection.close()

@app.post("/api/plants")
def create_plant():
    try:
        values = _plant_values(request.get_json(silent=True) or {})
    except ValueError as error:
        return jsonify({"message": str(error)}), 400

    connection = None
    try:
        connection = get_connection()
        cursor = connection.cursor()
        category_id = _category_id(cursor, values["category_name"])
        cursor.execute(
            """
            INSERT INTO plants
                (plant_name, category_id, price, stock_quantity,
                 sunlight_requirement, water_requirement, recommendation_priority)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            """,
            (
                values["plant_name"], category_id, values["price"],
                values["stock_quantity"], values["sunlight_requirement"],
                values["water_requirement"], values["recommendation_priority"],
            ),
        )
        plant_id = cursor.lastrowid
        connection.commit()
        cursor.close()
        return jsonify({"message": "Plant added.", "plant_id": plant_id}), 201
    except Error:
        if connection:
            connection.rollback()
        app.logger.exception("Could not create plant")
        return jsonify({"message": "Could not save the plant to MySQL."}), 503
    finally:
        if connection:
            connection.close()


@app.put("/api/plants/<int:plant_id>")
def update_plant(plant_id):
    try:
        values = _plant_values(request.get_json(silent=True) or {})
    except ValueError as error:
        return jsonify({"message": str(error)}), 400

    connection = None
    try:
        connection = get_connection()
        cursor = connection.cursor()
        category_id = _category_id(cursor, values["category_name"])
        cursor.execute(
            """
            UPDATE plants
            SET plant_name = %s, category_id = %s, price = %s,
                stock_quantity = %s, sunlight_requirement = %s,
                water_requirement = %s, recommendation_priority = %s
            WHERE plant_id = %s
            """,
            (
                values["plant_name"], category_id, values["price"],
                values["stock_quantity"], values["sunlight_requirement"],
                values["water_requirement"], values["recommendation_priority"],
                plant_id,
            ),
        )
        if cursor.rowcount == 0:
            cursor.execute("SELECT plant_id FROM plants WHERE plant_id = %s", (plant_id,))
            exists = cursor.fetchone()
            if not exists:
                cursor.close()
                connection.rollback()
                return jsonify({"message": "Plant not found."}), 404
        connection.commit()
        cursor.close()
        return jsonify({"message": "Plant updated."})
    except Error:
        if connection:
            connection.rollback()
        app.logger.exception("Could not update plant")
        return jsonify({"message": "Could not update the plant in MySQL."}), 503
    finally:
        if connection:
            connection.close()


@app.delete("/api/plants/<int:plant_id>")
def delete_plant(plant_id):
    connection = None
    try:
        connection = get_connection()
        cursor = connection.cursor()
        cursor.execute("DELETE FROM plants WHERE plant_id = %s", (plant_id,))
        if cursor.rowcount == 0:
            cursor.close()
            return jsonify({"message": "Plant not found."}), 404
        connection.commit()
        cursor.close()
        return jsonify({"message": "Plant deleted."})
    except Error as error:
        if connection:
            connection.rollback()
        if error.errno == 1451:
            return jsonify({"message": "This plant is in an order and cannot be deleted."}), 409
        app.logger.exception("Could not delete plant")
        return jsonify({"message": "Could not delete the plant from MySQL."}), 503
    finally:
        if connection:
            connection.close()

@app.get("/api/recommendations")
def recommend_plants():
    try:
        budget = Decimal(request.args.get("budget", ""))

        if not budget.is_finite() or budget < 0:
            raise InvalidOperation

    except (InvalidOperation, TypeError, ValueError):
        return jsonify({"message": "Enter a valid budget of 0 or more."}), 400

    connection = None
    try:
        connection = get_connection()
        catalogue = _read_plants(connection)
        result = recommend_plants_within_budget(
            catalogue.to_list(),
            float(budget)
        )

        return jsonify(result)

    except Error:
        app.logger.exception("Could not recommend plants")
        return jsonify({"message": "Could not load plants for recommendations."}), 503

    finally:
        if connection:
            connection.close()

@app.post("/api/calculate")
def calculate_expression():
    data = request.get_json(silent=True) or {}
    expression = str(data.get("expression", "")).strip()

    try:
        result = evaluate_postfix(expression)
        return jsonify({"result": result})
    except ValueError as error:
        return jsonify({"message": str(error)}), 400
@app.get("/api/plant-tree")
def plant_tree_operations():
    connection = None

    try:
        connection = get_connection()
        plants = _read_plants(connection).to_list()

        tree = PlantBST()
        for plant in plants:
            tree.insert(plant)

        plant_id = request.args.get("id", type=int)

        if plant_id is not None:
            match = tree.search(plant_id)
            return jsonify({
                "plant": match,
                "found": match is not None,
                "method": "Binary Search Tree search",
            })

        order = request.args.get("order", "inorder").lower()
        traversals = {
            "inorder": tree.inorder,
            "preorder": tree.preorder,
            "postorder": tree.postorder,
        }

        if order not in traversals:
            return jsonify({
                "message": "Choose inorder, preorder, or postorder."
            }), 400

        result = traversals[order]()

        return jsonify({
            "plants": result,
            "count": len(result),
            "method": f"BST {order} traversal",
        })

    except Error:
        app.logger.exception("Could not process the plant tree")
        return jsonify({"message": "Could not load plants for the tree."}), 503

    finally:
        if connection:
            connection.close()

@app.get("/api/customers")
def list_customers():
    connection = None
    try:
        connection = get_connection()
        cursor = connection.cursor(dictionary=True)
        cursor.execute(
            "SELECT customer_id, customer_name, email, phone, created_at "
            "FROM customers ORDER BY customer_id"
        )
        customers = cursor.fetchall()
        cursor.close()
        for customer in customers:
            customer["created_at"] = customer["created_at"].isoformat()
        return jsonify({"customers": customers, "count": len(customers)})
    except Error:
        app.logger.exception("Could not load customers")
        return jsonify({"message": "Could not load customers from MySQL."}), 503
    finally:
        if connection:
            connection.close()


@app.post("/api/customers")
def create_customer():
    data = request.get_json(silent=True) or {}
    name = str(data.get("customer_name", "")).strip()
    email = str(data.get("email", "")).strip() or None
    phone = str(data.get("phone", "")).strip() or None
    if not name:
        return jsonify({"message": "Customer name is required."}), 400

    connection = None
    try:
        connection = get_connection()
        cursor = connection.cursor()
        cursor.execute(
            "INSERT INTO customers (customer_name, email, phone) VALUES (%s, %s, %s)",
            (name, email, phone),
        )
        customer_id = cursor.lastrowid
        connection.commit()
        cursor.close()
        return jsonify({"message": "Customer added.", "customer_id": customer_id}), 201
    except Error as error:
        if connection:
            connection.rollback()
        if error.errno == 1062:
            return jsonify({"message": "That email or phone is already used by another customer."}), 409
        app.logger.exception("Could not create customer")
        return jsonify({"message": "Could not save the customer to MySQL."}), 503
    finally:
        if connection:
            connection.close()


@app.get("/api/orders")
def list_orders():
    connection = None
    try:
        connection = get_connection()
        cursor = connection.cursor(dictionary=True)
        cursor.execute(
            """
            SELECT o.order_id, o.customer_id, c.customer_name, o.order_status,
                   o.order_total, o.created_at
            FROM orders AS o
            JOIN customers AS c ON c.customer_id = o.customer_id
            ORDER BY o.created_at DESC, o.order_id DESC
            """
        )
        orders = cursor.fetchall()
        cursor.close()
        for order in orders:
            order["order_total"] = float(order["order_total"])
            order["created_at"] = order["created_at"].isoformat()

        queue = LinkedQueue()
        for order in sorted(
            (row for row in orders if row["order_status"] == "Queued"),
            key=lambda row: (row["created_at"], row["order_id"]),
        ):
            queue.enqueue(order["order_id"])
        return jsonify({
            "orders": orders,
            "queued_order_ids": queue.to_list(),
            "queued_count": len(queue),
            "method": "Queued orders are arranged FIFO with a linked-list-backed queue.",
        })
    except Error:
        app.logger.exception("Could not load orders")
        return jsonify({"message": "Could not load orders from MySQL."}), 503
    finally:
        if connection:
            connection.close()


@app.post("/api/orders")
def create_order():
    data = request.get_json(silent=True) or {}
    try:
        customer_id = int(data.get("customer_id"))
        items = data.get("items")
        if not isinstance(items, list) or not items:
            raise ValueError
        quantities = {}
        for item in items:
            plant_id = int(item.get("plant_id"))
            quantity = int(item.get("quantity"))
            if plant_id < 1 or quantity < 1:
                raise ValueError
            quantities[plant_id] = quantities.get(plant_id, 0) + quantity
    except (AttributeError, TypeError, ValueError):
        return jsonify({"message": "Choose a customer and add at least one plant with a positive quantity."}), 400

    connection = None
    cursor = None
    try:
        connection = get_connection()
        connection.start_transaction()
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT customer_id FROM customers WHERE customer_id = %s", (customer_id,))
        if not cursor.fetchone():
            connection.rollback()
            return jsonify({"message": "Customer not found."}), 404

        order_lines = []
        total = Decimal("0.00")
        for plant_id, quantity in quantities.items():
            cursor.execute(
                "SELECT plant_name, price, stock_quantity FROM plants WHERE plant_id = %s FOR UPDATE",
                (plant_id,),
            )
            plant = cursor.fetchone()
            if not plant:
                connection.rollback()
                return jsonify({"message": f"Plant {plant_id} was not found."}), 404
            if plant["stock_quantity"] < quantity:
                connection.rollback()
                return jsonify({
                    "message": f"Not enough stock for {plant['plant_name']}. Available: {plant['stock_quantity']}."
                }), 409
            unit_price = Decimal(str(plant["price"]))
            total += unit_price * quantity
            order_lines.append((plant_id, quantity, unit_price))

        cursor.execute(
            "INSERT INTO orders (customer_id, order_total) VALUES (%s, %s)",
            (customer_id, total),
        )
        order_id = cursor.lastrowid
        for plant_id, quantity, unit_price in order_lines:
            cursor.execute(
                "INSERT INTO order_items (order_id, plant_id, quantity, unit_price) VALUES (%s, %s, %s, %s)",
                (order_id, plant_id, quantity, unit_price),
            )
            cursor.execute(
                "UPDATE plants SET stock_quantity = stock_quantity - %s WHERE plant_id = %s",
                (quantity, plant_id),
            )
        connection.commit()
        return jsonify({"message": "Order placed and added to the FIFO queue.", "order_id": order_id, "order_total": float(total)}), 201
    except Error:
        if connection:
            connection.rollback()
        app.logger.exception("Could not create order")
        return jsonify({"message": "Could not save the order to MySQL."}), 503
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()


@app.post("/api/orders/process-next")
def process_next_order():
    connection = None
    cursor = None
    try:
        connection = get_connection()
        connection.start_transaction()
        cursor = connection.cursor()
        cursor.execute(
            "SELECT order_id FROM orders WHERE order_status = 'Queued' "
            "ORDER BY created_at, order_id FOR UPDATE"
        )
        queue = LinkedQueue()
        for (order_id,) in cursor.fetchall():
            queue.enqueue(order_id)
        next_order_id = queue.dequeue()
        if next_order_id is None:
            connection.rollback()
            return jsonify({"message": "There are no queued orders to process."}), 404
        cursor.execute(
            "UPDATE orders SET order_status = 'Processing' WHERE order_id = %s",
            (next_order_id,),
        )
        connection.commit()
        return jsonify({
            "message": "The oldest order moved to Processing.",
            "order_id": next_order_id,
            "remaining_queued_order_ids": queue.to_list(),
        })
    except Error:
        if connection:
            connection.rollback()
        app.logger.exception("Could not process next order")
        return jsonify({"message": "Could not process the next order."}), 503
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()


@app.post("/api/orders/<int:order_id>/complete")
def complete_order(order_id):
    connection = None
    cursor = None
    try:
        connection = get_connection()
        cursor = connection.cursor()
        cursor.execute(
            "UPDATE orders SET order_status = 'Completed' "
            "WHERE order_id = %s AND order_status = 'Processing'",
            (order_id,),
        )
        if cursor.rowcount == 0:
            cursor.close()
            return jsonify({"message": "Only a Processing order can be completed."}), 409
        connection.commit()
        return jsonify({"message": "Order completed."})
    except Error:
        if connection:
            connection.rollback()
        app.logger.exception("Could not complete order")
        return jsonify({"message": "Could not complete the order."}), 503
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()
@app.post("/api/nursery-sections")
def create_nursery_section():
    data = request.get_json(silent=True) or {}
    name = str(data.get("section_name", "")).strip()
    description = str(data.get("description", "")).strip() or None

    if not name:
        return jsonify({"message": "Section name is required."}), 400

    connection = None
    cursor = None

    try:
        connection = get_connection()
        cursor = connection.cursor()
        cursor.execute(
            "INSERT INTO nursery_sections (section_name, description) "
            "VALUES (%s, %s)",
            (name, description)
        )
        connection.commit()
        return jsonify({"message": "Nursery section added."}), 201

    except Error:
        if connection:
            connection.rollback()
        app.logger.exception("Could not add nursery section")
        return jsonify({"message": "Could not add the section. Check whether its name is already used."}), 400

    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()


@app.post("/api/section-connections")
def create_section_connection():
    data = request.get_json(silent=True) or {}

    try:
        section_id = int(data.get("section_id"))
        connected_id = int(data.get("connected_section_id"))
    except (TypeError, ValueError):
        return jsonify({"message": "Choose two valid section IDs."}), 400

    if section_id == connected_id:
        return jsonify({"message": "Choose two different sections."}), 400

    connection = None
    cursor = None

    try:
        connection = get_connection()
        cursor = connection.cursor()
        cursor.execute(
            "INSERT INTO section_connections "
            "(section_id, connected_section_id) VALUES (%s, %s)",
            (section_id, connected_id)
        )
        cursor.execute(
            "INSERT INTO section_connections "
            "(section_id, connected_section_id) VALUES (%s, %s)",
            (connected_id, section_id)
        )
        connection.commit()
        return jsonify({"message": "Sections connected."}), 201

    except Error:
        if connection:
            connection.rollback()
        app.logger.exception("Could not connect nursery sections")
        return jsonify({"message": "Could not connect them. Check the section IDs or whether this connection already exists."}), 400

    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()
            
@app.get("/api/nursery-graph")
def get_nursery_graph():
    connection = None
    cursor = None

    try:
        connection = get_connection()
        cursor = connection.cursor(dictionary=True)
        graph = NurseryGraph()

        cursor.execute(
            "SELECT section_id, section_name FROM nursery_sections"
        )
        sections = cursor.fetchall()

        for section in sections:
            graph.add_section(section["section_id"], section["section_name"])

        cursor.execute(
            "SELECT section_id, connected_section_id FROM section_connections"
        )
        connections = cursor.fetchall()

        for item in connections:
            graph.connect_sections(
                item["section_id"],
                item["connected_section_id"]
            )

        start_value = request.args.get("start_id", "").strip()
        if not start_value:
            return jsonify({"sections": sections, "traversal": []})

        try:
            start_id = int(start_value)
        except ValueError:
            return jsonify({"message": "Enter a valid section ID."}), 400

        if start_id not in graph.section_names:
            return jsonify({"message": "Section ID not found."}), 404

        return jsonify({
            "sections": sections,
            "traversal": graph.bfs(start_id)
        })

    except Error:
        app.logger.exception("Could not load nursery graph")
        return jsonify({"message": "Could not load nursery sections from MySQL."}), 503

    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

if __name__ == "__main__":
    app.run(debug=True)
