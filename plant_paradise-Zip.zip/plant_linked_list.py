import mysql.connector


class PlantNode:
    def __init__(self, plant_id, plant_name, category_id, price, stock_quantity):
        self.plant_id = plant_id
        self.plant_name = plant_name
        self.category_id = category_id
        self.price = price
        self.stock_quantity = stock_quantity
        self.next = None


class PlantLinkedList:
    def __init__(self):
        self.head = None

    def add_plant(self, plant_id, plant_name, category_id, price, stock_quantity):
        new_node = PlantNode(
            plant_id, plant_name, category_id, price, stock_quantity
        )

        if self.head is None:
            self.head = new_node
        else:
            current = self.head
            while current.next is not None:
                current = current.next
            current.next = new_node

    def display_plants(self):
        current = self.head

        if current is None:
            print("The plant list is empty.")
            return

        while current is not None:
            print(
                f"ID: {current.plant_id}, "
                f"Name: {current.plant_name}, "
                f"Category: {current.category_id}, "
                f"Price: {current.price}, "
                f"Stock: {current.stock_quantity}"
            )
            current = current.next

    def search_plant(self, plant_name):
        current = self.head

        while current is not None:
            if current.plant_name.lower() == plant_name.lower():
                print(
                    f"Found: {current.plant_name}, "
                    f"Price: {current.price}, "
                    f"Stock: {current.stock_quantity}"
                )
                return

            current = current.next

        print("Plant not found.")

    def update_plant(self, plant_id, new_price, new_stock):
        current = self.head

        while current is not None:
            if current.plant_id == plant_id:
                current.price = new_price
                current.stock_quantity = new_stock
                return True

            current = current.next

        return False

    def delete_plant(self, plant_id):
        current = self.head
        previous = None

        while current is not None:
            if current.plant_id == plant_id:
                if previous is None:
                    self.head = current.next
                else:
                    previous.next = current.next
                return True

            previous = current
            current = current.next

        return False


class ActionNode:
    def __init__(self, action):
        self.action = action
        self.next = None


class ActionStack:
    def __init__(self):
        self.top = None

    def push(self, action):
        new_node = ActionNode(action)
        new_node.next = self.top
        self.top = new_node

    def pop(self):
        if self.top is None:
            return "No recent actions."

        action = self.top.action
        self.top = self.top.next
        return action

    def display(self):
        current = self.top

        if current is None:
            print("No recent actions.")
            return

        while current is not None:
            print(current.action)
            current = current.next


def evaluate_postfix(expression):
    number_stack = ActionStack()

    for item in expression.split():
        if item in ("+", "-", "*", "/"):
            right = number_stack.pop()
            left = number_stack.pop()

            if item == "+":
                number_stack.push(left + right)
            elif item == "-":
                number_stack.push(left - right)
            elif item == "*":
                number_stack.push(left * right)
            else:
                number_stack.push(left / right)
        else:
            number_stack.push(float(item))

    return number_stack.pop()


class QueueNode:
    def __init__(self, order_id):
        self.order_id = order_id
        self.next = None


class OrderQueue:
    def __init__(self):
        self.front = None
        self.rear = None

    def enqueue(self, order_id):
        new_node = QueueNode(order_id)

        if self.rear is None:
            self.front = new_node
            self.rear = new_node
        else:
            self.rear.next = new_node
            self.rear = new_node

    def dequeue(self):
        if self.front is None:
            return None

        order_id = self.front.order_id
        self.front = self.front.next

        if self.front is None:
            self.rear = None

        return order_id

    def display(self):
        current = self.front

        if current is None:
            print("The order queue is empty.")
            return

        while current is not None:
            print(f"Order ID: {current.order_id}")
            current = current.next
class NurseryGraph:
    def __init__(self):
        self.section_names = {}
        self.connections = {}

    def add_section(self, section_id, section_name):
        self.section_names[section_id] = section_name
        self.connections[section_id] = []

    def add_connection(self, section_id, connected_section_id):
        if section_id in self.connections:
            if connected_section_id not in self.connections[section_id]:
                self.connections[section_id].append(connected_section_id)

        if connected_section_id in self.connections:
            if section_id not in self.connections[connected_section_id]:
                self.connections[connected_section_id].append(section_id)

    def bfs(self, start_id):
        if start_id not in self.section_names:
            print("Section ID not found.")
            return

        section_queue = OrderQueue()
        visited = {start_id}
        section_queue.enqueue(start_id)

        print("BFS traversal:")

        while section_queue.front is not None:
            current_id = section_queue.dequeue()
            print(self.section_names[current_id])

            for neighbor_id in self.connections[current_id]:
                if neighbor_id not in visited:
                    visited.add(neighbor_id)
                    section_queue.enqueue(neighbor_id)

class PlantTreeNode:
    def __init__(self, plant_id, plant_name, price):
        self.plant_id = plant_id
        self.plant_name = plant_name
        self.price = price
        self.left = None
        self.right = None


class PlantBST:
    def __init__(self):
        self.root = None

    def insert(self, plant_id, plant_name, price):
        new_node = PlantTreeNode(plant_id, plant_name, price)

        if self.root is None:
            self.root = new_node
            return

        current = self.root

        while True:
            if plant_id < current.plant_id:
                if current.left is None:
                    current.left = new_node
                    return
                current = current.left
            elif plant_id > current.plant_id:
                if current.right is None:
                    current.right = new_node
                    return
                current = current.right
            else:
                return

    def search(self, plant_id):
        current = self.root

        while current is not None:
            if plant_id == current.plant_id:
                return current
            elif plant_id < current.plant_id:
                current = current.left
            else:
                current = current.right

        return None

    def inorder(self):
        self._inorder(self.root)

    def _inorder(self, node):
        if node is not None:
            self._inorder(node.left)
            print(node.plant_id, node.plant_name, node.price)
            self._inorder(node.right)

    def preorder(self):
        self._preorder(self.root)

    def _preorder(self, node):
        if node is not None:
            print(node.plant_id, node.plant_name, node.price)
            self._preorder(node.left)
            self._preorder(node.right)

    def postorder(self):
        self._postorder(self.root)

    def _postorder(self, node):
        if node is not None:
            self._postorder(node.left)
            self._postorder(node.right)
            print(node.plant_id, node.plant_name, node.price)


def rebuild_plant_tree(plant_list):
    tree = PlantBST()
    current = plant_list.head

    while current is not None:
        tree.insert(current.plant_id, current.plant_name, current.price)
        current = current.next

    return tree
def bubble_sort_by_price(plant_list):
    plants = []
    current = plant_list.head

    while current is not None:
        plants.append(current)
        current = current.next

    for i in range(len(plants)):
        for j in range(len(plants) - i - 1):
            if plants[j].price > plants[j + 1].price:
                plants[j], plants[j + 1] = plants[j + 1], plants[j]

    return plants

connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="0922",
    database="plant_paradise"
)

cursor = connection.cursor()

cursor.execute("""
    SELECT plant_id, plant_name, category_id, price, stock_quantity
    FROM plants
""")

plant_list = PlantLinkedList()

for plant in cursor.fetchall():
    plant_list.add_plant(*plant)

plant_tree = rebuild_plant_tree(plant_list)
action_stack = ActionStack()
order_queue = OrderQueue()

cursor.execute(
    "SELECT order_id FROM orders "
    "WHERE order_status = 'Queued' "
    "ORDER BY order_id"
)

for (order_id,) in cursor.fetchall():
    order_queue.enqueue(order_id)
nursery_graph = NurseryGraph()

cursor.execute("SELECT section_id, section_name FROM nursery_sections")
for section_id, section_name in cursor.fetchall():
    nursery_graph.add_section(section_id, section_name)

cursor.execute(
    "SELECT section_id, connected_section_id FROM section_connections"
)
for section_id, connected_section_id in cursor.fetchall():
    nursery_graph.add_connection(section_id, connected_section_id)

while True:
    print("\n1. Display plants")
    print("2. Add a plant")
    print("3. Search by plant name")
    print("4. Update a plant")
    print("5. Delete a plant")
    print("6. View recent actions")
    print("7. Remove latest action from history")
    print("8. View order queue")
    print("9. Process next queued order")
    print("10. Calculate an expression")
    print("11. Search BST by plant ID")
    print("12. BST inorder traversal")
    print("13. BST preorder traversal")
    print("14. BST postorder traversal")
    print("15. BFS through nursery sections")
    print("16. Sort plants by price")
    print("17. Exit")

    choice = input("Choose an option: ")

    if choice == "1":
        plant_list.display_plants()

    elif choice == "2":
        name = input("Plant name: ")
        category_id = int(input("Category ID (use 1 for outdoor): "))
        price = float(input("Price: "))
        stock = int(input("Stock quantity: "))

        cursor.execute(
            "INSERT INTO plants (plant_name, category_id, price, stock_quantity) "
            "VALUES (%s, %s, %s, %s)",
            (name, category_id, price, stock)
        )
        connection.commit()

        plant_id = cursor.lastrowid
        plant_list.add_plant(plant_id, name, category_id, price, stock)
        plant_tree = rebuild_plant_tree(plant_list)
        action_stack.push(f"Added {name} (ID {plant_id})")
        print("Plant added!")

    elif choice == "3":
        name = input("Enter the plant name: ")
        plant_list.search_plant(name)

    elif choice == "4":
        plant_id = int(input("Enter the plant ID to update: "))
        new_price = float(input("Enter the new price: "))
        new_stock = int(input("Enter the new stock quantity: "))

        cursor.execute(
            "UPDATE plants SET price = %s, stock_quantity = %s "
            "WHERE plant_id = %s",
            (new_price, new_stock, plant_id)
        )

        if cursor.rowcount > 0:
            connection.commit()
            plant_list.update_plant(plant_id, new_price, new_stock)
            plant_tree = rebuild_plant_tree(plant_list)
            action_stack.push(f"Updated plant ID {plant_id}")
            print("Plant updated!")
        else:
            connection.rollback()
            print("Plant ID not found.")

    elif choice == "5":
        plant_id = int(input("Enter the plant ID to delete: "))

        cursor.execute(
            "DELETE FROM plants WHERE plant_id = %s",
            (plant_id,)
        )

        if cursor.rowcount > 0:
            connection.commit()
            plant_list.delete_plant(plant_id)
            plant_tree = rebuild_plant_tree(plant_list)
            action_stack.push(f"Deleted plant ID {plant_id}")
            print("Plant deleted!")
        else:
            connection.rollback()
            print("Plant ID not found.")

    elif choice == "6":
        action_stack.display()

    elif choice == "7":
        print(action_stack.pop())

    elif choice == "8":
        order_queue.display()

    elif choice == "9":
        order_id = order_queue.dequeue()

        if order_id is None:
            print("The order queue is empty.")
        else:
            cursor.execute(
                "UPDATE orders SET order_status = 'Processing' "
                "WHERE order_id = %s AND order_status = 'Queued'",
                (order_id,)
            )

            if cursor.rowcount > 0:
                connection.commit()
                action_stack.push(f"Started processing order {order_id}")
                print(f"Order {order_id} is now Processing.")
            else:
                connection.rollback()
                print(f"Order {order_id} is no longer queued.")

    elif choice == "10":
        expression = input(
            "Enter postfix expression (example: 20 5 2 * +): "
        )
        print("Result:", evaluate_postfix(expression))

    elif choice == "11":
        plant_id = int(input("Enter plant ID to search for: "))
        result = plant_tree.search(plant_id)

        if result is None:
            print("Plant ID not found.")
        else:
            print(
                f"Found: ID {result.plant_id}, "
                f"Name: {result.plant_name}, Price: {result.price}"
            )

    elif choice == "12":
        plant_tree.inorder()

    elif choice == "13":
        plant_tree.preorder()

    elif choice == "14":
        plant_tree.postorder()

    elif choice == "15":
        if not nursery_graph.section_names:
            print("No nursery sections are stored in the database.")
        else:
            for section_id, section_name in nursery_graph.section_names.items():
                print(f"{section_id}: {section_name}")

            start_id = int(input("Enter the starting section ID: "))
            nursery_graph.bfs(start_id)

    elif choice == "16":
        sorted_plants = bubble_sort_by_price(plant_list)

        for plant in sorted_plants:
            print(f"{plant.plant_name}: {plant.price}")

    elif choice == "17":
        break

    else:
        print("Please choose a number from 1 to 17.")

cursor.close()
connection.close()
