class StackNode:
    def __init__(self, value):
        self.value = value
        self.next = None


class LinkedStack:
    def __init__(self):
        self.top = None
        self.size = 0

    def push(self, value):
        new_node = StackNode(value)
        new_node.next = self.top
        self.top = new_node
        self.size += 1

    def pop(self):
        if self.top is None:
            return None

        value = self.top.value
        self.top = self.top.next
        self.size -= 1
        return value

    def to_list(self):
        values = []
        current = self.top

        while current is not None:
            values.append(current.value)
            current = current.next

        return values

    def __len__(self):
        return self.size


def evaluate_postfix(expression):
    stack = LinkedStack()
    operators = {"+", "-", "*", "/"}

    for item in expression.split():
        if item in operators:
            right = stack.pop()
            left = stack.pop()

            if left is None or right is None:
                raise ValueError("The expression is incomplete.")

            if item == "+":
                stack.push(left + right)
            elif item == "-":
                stack.push(left - right)
            elif item == "*":
                stack.push(left * right)
            else:
                if right == 0:
                    raise ValueError("Cannot divide by zero.")
                stack.push(left / right)
        else:
            try:
                stack.push(float(item))
            except ValueError:
                raise ValueError(f"Invalid item: {item}") from None

    if len(stack) != 1:
        raise ValueError("Check the expression format.")

    return stack.pop()