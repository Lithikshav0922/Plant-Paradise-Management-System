class NurseryGraph:
    def __init__(self):
        self.section_names = {}
        self.connections = {}

    def add_section(self, section_id, section_name):
        self.section_names[section_id] = section_name
        self.connections.setdefault(section_id, [])

    def connect_sections(self, first_id, second_id):
        if first_id not in self.section_names or second_id not in self.section_names:
            raise ValueError("Both sections must exist before connecting them.")

        if second_id not in self.connections[first_id]:
            self.connections[first_id].append(second_id)

        if first_id not in self.connections[second_id]:
            self.connections[second_id].append(first_id)

    def bfs(self, start_id):
        if start_id not in self.section_names:
            return []

        visited = {start_id}
        queue = [start_id]
        visit_order = []

        while queue:
            current_id = queue.pop(0)
            visit_order.append({
                "section_id": current_id,
                "section_name": self.section_names[current_id],
            })

            for neighbor_id in self.connections[current_id]:
                if neighbor_id not in visited:
                    visited.add(neighbor_id)
                    queue.append(neighbor_id)

        return visit_order