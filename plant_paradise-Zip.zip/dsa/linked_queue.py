class QueueNode:
    """A node in the linked-list-backed FIFO order queue."""

    def __init__(self, value):
        self.value = value
        self.next = None


class LinkedQueue:
    """First-in, first-out queue with O(1) enqueue and dequeue."""

    def __init__(self):
        self.front = None
        self.rear = None
        self.length = 0

    def enqueue(self, value):
        node = QueueNode(value)
        if self.rear is None:
            self.front = self.rear = node
        else:
            self.rear.next = node
            self.rear = node
        self.length += 1

    def dequeue(self):
        if self.front is None:
            return None
        value = self.front.value
        self.front = self.front.next
        if self.front is None:
            self.rear = None
        self.length -= 1
        return value

    def peek(self):
        return None if self.front is None else self.front.value

    def to_list(self):
        items = []
        current = self.front
        while current is not None:
            items.append(current.value)
            current = current.next
        return items

    def __len__(self):
        return self.length
