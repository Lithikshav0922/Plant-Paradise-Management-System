class PlantTreeNode:
    def __init__(self, plant):
        self.plant = plant
        self.left = None
        self.right = None


class PlantBST:
    def __init__(self):
        self.root = None

    def insert(self, plant):
        new_node = PlantTreeNode(plant)

        if self.root is None:
            self.root = new_node
            return

        current = self.root

        while True:
            if plant["plant_id"] < current.plant["plant_id"]:
                if current.left is None:
                    current.left = new_node
                    return
                current = current.left
            else:
                if current.right is None:
                    current.right = new_node
                    return
                current = current.right

    def search(self, plant_id):
        current = self.root

        while current is not None:
            current_id = current.plant["plant_id"]

            if current_id == plant_id:
                return current.plant
            elif plant_id < current_id:
                current = current.left
            else:
                current = current.right

        return None

    def inorder(self):
        result = []

        def visit(node):
            if node is not None:
                visit(node.left)
                result.append(node.plant)
                visit(node.right)

        visit(self.root)
        return result

    def preorder(self):
        result = []

        def visit(node):
            if node is not None:
                result.append(node.plant)
                visit(node.left)
                visit(node.right)

        visit(self.root)
        return result

    def postorder(self):
        result = []

        def visit(node):
            if node is not None:
                visit(node.left)
                visit(node.right)
                result.append(node.plant)

        visit(self.root)
        return result