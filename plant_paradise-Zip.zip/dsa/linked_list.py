class Node:
    """A node in the singly linked plant catalogue."""

    def __init__(self, value):
        self.value = value
        self.next = None


class LinkedList:
    """Singly linked list used to traverse and linearly search plants."""

    def __init__(self):
        self.head = None
        self.tail = None
        self.length = 0

    def append(self, value):
        node = Node(value)
        if self.head is None:
            self.head = node
        else:
            self.tail.next = node
        self.tail = node
        self.length += 1

    def find(self, predicate):
        current = self.head
        while current is not None:
            if predicate(current.value):
                return current.value
            current = current.next
        return None

    def remove(self, predicate):
        previous = None
        current = self.head
        while current is not None:
            if predicate(current.value):
                if previous is None:
                    self.head = current.next
                else:
                    previous.next = current.next
                if current is self.tail:
                    self.tail = previous
                self.length -= 1
                return current.value
            previous, current = current, current.next
        return None

    def to_list(self):
        values = []
        current = self.head
        while current is not None:
            values.append(current.value)
            current = current.next
        return values

    def __len__(self):
        return self.length
