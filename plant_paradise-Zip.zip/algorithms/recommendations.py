def recommend_plants_within_budget(plants, budget):
    """Choose affordable, in-stock plants from cheapest to most expensive."""
    remaining = float(budget)
    recommendations = []

    available_plants = sorted(
        plants,
        key=lambda plant: float(plant["price"])
    )

    for plant in available_plants:
        price = float(plant["price"])
        stock = int(plant["stock_quantity"])

        # Recommend one of each plant variety, if it is in stock
        # and fits within the remaining budget.
        if stock > 0 and price <= remaining:
            recommendations.append(plant)
            remaining = round(remaining - price, 2)

    spent = round(float(budget) - remaining, 2)

    return {
        "recommendations": recommendations,
        "spent": spent,
        "remaining": remaining,
    }