def bubble_sort_by_price(plants):
    sorted_plants = list(plants)

    for i in range(len(sorted_plants)):
        for j in range(len(sorted_plants) - i - 1):
            if sorted_plants[j]["price"] > sorted_plants[j + 1]["price"]:
                sorted_plants[j], sorted_plants[j + 1] = (
                    sorted_plants[j + 1],
                    sorted_plants[j],
                )

    return sorted_plants
def binary_search_by_id(plants, target_id):
    low = 0
    high = len(plants) - 1

    while low <= high:
        middle = (low + high) // 2
        current_id = plants[middle]["plant_id"]

        if current_id == target_id:
            return plants[middle]
        elif current_id < target_id:
            low = middle + 1
        else:
            high = middle - 1

    return None