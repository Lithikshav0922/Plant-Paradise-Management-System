CREATE DATABASE IF NOT EXISTS plant_paradise
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_0900_ai_ci;
USE plant_paradise;

CREATE TABLE IF NOT EXISTS categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(80) NOT NULL UNIQUE,
    description VARCHAR(255)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS plants (
    plant_id INT AUTO_INCREMENT PRIMARY KEY,
    plant_name VARCHAR(120) NOT NULL,
    category_id INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    stock_quantity INT NOT NULL DEFAULT 0,
    sunlight_requirement VARCHAR(80),
    water_requirement VARCHAR(80),
    recommendation_priority INT NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_plants_category FOREIGN KEY (category_id) REFERENCES categories(category_id),
    CONSTRAINT chk_plants_price CHECK (price >= 0),
    CONSTRAINT chk_plants_stock CHECK (stock_quantity >= 0),
    CONSTRAINT chk_plants_priority CHECK (recommendation_priority > 0),
    INDEX idx_plants_name (plant_name)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS customers (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(120) NOT NULL,
    email VARCHAR(255) UNIQUE,
    phone VARCHAR(25),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    order_status ENUM('Queued', 'Processing', 'Completed', 'Cancelled') NOT NULL DEFAULT 'Queued',
    order_total DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_orders_customer FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    CONSTRAINT chk_orders_total CHECK (order_total >= 0),
    INDEX idx_orders_queue (order_status, created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS order_items (
    order_item_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    plant_id INT NOT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    CONSTRAINT fk_items_order FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
    CONSTRAINT fk_items_plant FOREIGN KEY (plant_id) REFERENCES plants(plant_id),
    CONSTRAINT chk_items_quantity CHECK (quantity > 0),
    CONSTRAINT chk_items_price CHECK (unit_price >= 0)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS nursery_sections (
    section_id INT AUTO_INCREMENT PRIMARY KEY,
    section_name VARCHAR(100) NOT NULL UNIQUE,
    description VARCHAR(255)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS section_connections (
    section_id INT NOT NULL,
    connected_section_id INT NOT NULL,
    PRIMARY KEY (section_id, connected_section_id),
    CONSTRAINT fk_connection_section FOREIGN KEY (section_id) REFERENCES nursery_sections(section_id) ON DELETE CASCADE,
    CONSTRAINT fk_connection_target FOREIGN KEY (connected_section_id) REFERENCES nursery_sections(section_id) ON DELETE CASCADE,
    CONSTRAINT chk_no_self_connection CHECK (section_id <> connected_section_id)
) ENGINE=InnoDB;
