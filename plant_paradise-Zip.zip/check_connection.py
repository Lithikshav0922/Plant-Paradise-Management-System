import mysql.connector

connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="0922",
    database="plant_paradise"
)

print("Connected to plant_paradise!")
connection.close()